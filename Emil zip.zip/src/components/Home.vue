<template>
    <div class="ChargePage">
      <h5>My charges: 4</h5>
      <div id="feedbackDiv"></div>
    <div>
        <button class="hugeButton" @click="startCharge">Start charging
      <img src="../../src/assets/battery-charge-status-icon.svg" alt="../../src/assets/battery-charge-status-icon.svg"></button>
        </div>
    <div>
        <button class="hugeButton" @click="buyCharge">Purchase charges
      <img src="../../src/assets/repeat-arrow.svg" alt="../../src/assets/repeat-arrow.svg" id="flipSVG"></button>
        </div>
    </div>
</template>

<script>
export default {
  name: "Charge",
  data() {
    return {};
  },
  methods: {
    startCharge() {
      this.$router.push({ name: "StartCharge" });
    },
    buyCharge() {
      this.$router.push({ name: "BuyCharge" });
    },
    home() {
      this.$router.push({ name: "Home" });
    }
  }
};
</script>
<style scoped>
  #flipSVG {
        -moz-transform: scaleX(-1);
        -o-transform: scaleX(-1);
        -webkit-transform: scaleX(-1);
        transform: scaleX(-1);
        filter: FlipH;
        -ms-filter: "FlipH";   
  }
  img {
 width: 20%;
 float: right;
  }
</style>
