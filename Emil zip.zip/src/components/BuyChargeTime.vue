<template>
    <div class="Purchase">
      <h3>Your current balance:</h3>
      <h3>{{ credits }}</h3>
      <div id="feedbackDiv"></div>
    <div>
        <button class="smallButton" @click="confirmedPurchase1" value="1">1</button>
        <button class="smallButton" @click="confirmedPurchase5" value="5">5</button>
        <button class="smallButton" @click="confirmedPurchase10" value="10">10</button>
        <button class="smallButton" @click="confirmedPurchase25" value="25">25</button>
        </div>
    <div>
        <button class="button1" @click="buyCharge">Back</button>
        </div>
    </div>
</template>

<script>
import db from "@/firebase/init";
import firebase from "firebase";

export default {
  name: "BuyChargeTime",
  firebase: {},
  data() {
    return {
      user: null,
      credits: 0
    };
  },
  methods: {
    confirmedPurchase1() {
      this.user = firebase.auth().currentUser;
      // user.uid
      console.log("credits: " + this.credits)
      db.collection("users")
        .doc(this.user.uid)
        .set(
          {
            credits: this.credits
          },
          { merge: true }
        )
        .then(function() {
          console.log("Credits successfully updated: ");
        })
        .catch(function(error) {
          console.error("Error writing document: ", error);
        });
      /*this.credits = this.credits + 1; 
      firebase.auth().updateCurrentUser(this.user)
        .then(cred => {
      firebase.database().ref(cred.user.uid).update({
        credits: this.credits + 1
      })
        }).then(() => {
      this.$router.push({ name: "ConfirmedPurchase" });
        })
        .catch(err => {
            this.feedback = err.message
        })*/
    },
    confirmedPurchase5() {
      this.credits = this.credits + 5;
      firebase
        .auth()
        .updateCurrentUser(this.user)
        .then(cred => {
          firebase
            .database()
            .ref(cred.user.uid)
            .get({
              email: this.email,
              password: this.password
            }),
            firebase
              .database()
              .ref(cred.user.uid)
              .set({
                credits: this.credits
              });
        })
        .then(() => {
          this.$router.push({ name: "ConfirmedPurchase" });
        })
        .catch(err => {
          this.feedback = err.message;
        });
    },
    confirmedPurchase10() {
      this.credits = this.credits + 10;
      firebase
        .auth()
        .updateCurrentUser(this.user)
        .then(cred => {
          firebase
            .database()
            .ref(cred.user.uid)
            .get({
              email: this.email,
              password: this.password
            }),
            firebase
              .database()
              .ref(cred.user.uid)
              .set({
                credits: this.credits
              });
        })
        .then(() => {
          this.$router.push({ name: "ConfirmedPurchase" });
        })
        .catch(err => {
          this.feedback = err.message;
        });
    },
    confirmedPurchase25() {
      this.credits = this.credits + 25;
      firebase
        .auth()
        .updateCurrentUser(this.user)
        .then(cred => {
          firebase
            .database()
            .ref(cred.user.uid)
            .get({
              email: this.email,
              password: this.password
            }),
            firebase
              .database()
              .ref(cred.user.uid)
              .set({
                credits: this.credits
              });
        })
        .then(() => {
          this.$router.push({ name: "ConfirmedPurchase" });
        })
        .catch(err => {
          this.feedback = err.message;
        });
    },
    buyCharge() {
      this.$router.push({ name: "BuyCharge" });
    }
  },
  updated(){
    this.user = firebase.auth().currentUser;
    var docRef = db.collection("users").doc(this.user.uid);

docRef.get()
.then((doc) => {
    if (doc.exists) {
        console.log("Document data:", doc.data());
        this.credits = doc.data().credits;
    } else {
        // doc.data() will be undefined in this case
        console.log("No such document!");
    }
}).catch(function(error) {
    console.log("Error getting document:", error);
});
  }
};
</script>