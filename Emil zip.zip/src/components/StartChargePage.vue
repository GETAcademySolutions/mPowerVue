<template>
  <div class="StartChargePage">
      <!--<h5 style="font-weight: bold;">Start Charging</h5>
      <p>_____________________________________________________</p>
      <div id="feedbackDiv"></div>
    <div>      
        <div class="containmentDiv" style="text-align: left; padding-left: 20px; font-weight: bold; padding-top: 10px;">
          Kiosk ID    
          <p style="font-weight: normal;">9845, Bomba Roomba</p>       
        </div>
        <div class="containmentDiv" style="text-align: left; padding-left: 20px; font-weight: bold; padding-top: 10px;"> 
          Payment       
          <p style="font-weight: normal;">My charges: 4</p>                
        </div>
        <div class="containmentDiv" style="text-align: left; padding-left: 20px; font-weight: bold; padding-top: 10px;">  
          Device        
          <p style="font-weight: normal;">This phone, full charging</p>             
        </div>-->
        <div>
          <button class="button1" @click="connectToBluetooth">Connect charger</button>
        </div>
      <div>
        <button class="smallButton" @click="startCharging1">Open Port 1</button>
        <button class="smallButton" @click="startCharging2">Open Port 2</button>
        <button class="smallButton" @click="startCharging3">Open Port 3</button>
        <button class="smallButton" @click="startCharging4">Open Port 4</button>
      </div>
      <div>
        <button class="smallButton" @click="stopCharging1">Close Port 1</button>
        <button class="smallButton" @click="stopCharging2">Close Port 2</button>
        <button class="smallButton" @click="stopCharging3">Close Port 3</button>
        <button class="smallButton" @click="stopCharging4">Close Port 4</button>
      </div>
      <p id="output"></p>
    <div>
        <button class="button2" @click="home" style="margin-top: 20%;">Cancel</button>
        </div>
    </div>
  <!--</div>-->
</template>

<script>
import mPowerBluetoothController from "@/bluetooth/mPowerBluetoothController";
export default {
  name: "StartCharge",
  data() {
    const x = new mPowerBluetoothController();
    console.log("creating controller", x);
    return { controller: x };
  },
  methods: {
    home() {
      this.$router.push({ name: "Home" });
    },
    async connectToBluetooth() {
      console.log(this.controller);
      if (!this.controller.isConnected) {
        var controllerName = await this.controller.connect();
        output.innerHTML = "You are connected to " + controllerName;
      }
    },
    async startCharging1() {      
      if (!this.controller.isConnected) {
        output.innerHTML = "You're not connected, please reconnect";
        return;
      }
      await this.controller.turnOnOrOff("01", "01");
      const result = await this.controller.readValue();
      output.innerHTML += "<br />" + result;
    },
    async startCharging2() {      
      if (!this.controller.isConnected) {
        output.innerHTML = "You're not connected, please reconnect";
        return;
      }
      await this.controller.turnOnOrOff("02", "01");
      const result = await this.controller.readValue();
      output.innerHTML += "<br />" + result;
    },
    async startCharging3() {      
      if (!this.controller.isConnected) {
        output.innerHTML = "You're not connected, please reconnect";
        return;
      }
      await this.controller.turnOnOrOff("03", "01");
      const result = await this.controller.readValue();
      output.innerHTML += "<br />" + result;
    },
    async startCharging4() {      
      if (!this.controller.isConnected) {
        output.innerHTML = "You're not connected, please reconnect";
        return;
      }
      await this.controller.turnOnOrOff("04", "01");
      const result = await this.controller.readValue();
      output.innerHTML += "<br />" + result;
    },
    async stopCharging1() {      
      if (!this.controller.isConnected) {
        output.innerHTML = "You're not connected, please reconnect";
        return;
      }
      await this.controller.turnOnOrOff("01", "00");
      const result = await this.controller.readValue();
      output.innerHTML += "<br />" + result;
    },
    async stopCharging2() {      
      if (!this.controller.isConnected) {
        output.innerHTML = "You're not connected, please reconnect";
        return;
      }
      await this.controller.turnOnOrOff("02", "00");
      const result = await this.controller.readValue();
      output.innerHTML += "<br />" + result;
    },
    async stopCharging3() {      
      if (!this.controller.isConnected) {
        output.innerHTML = "You're not connected, please reconnect";
        return;
      }
      await this.controller.turnOnOrOff("03", "00");
      const result = await this.controller.readValue();
      output.innerHTML += "<br />" + result;
    },
    async stopCharging4() {      
      if (!this.controller.isConnected) {
        output.innerHTML = "You're not connected, please reconnect";
        return;
      }
      await this.controller.turnOnOrOff("04", "00");
      const result = await this.controller.readValue();
      output.innerHTML += "<br />" + result;
    }
  }
};
</script>