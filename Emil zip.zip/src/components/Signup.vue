<template>
    <div class="signup">
      <form class="card-panel" @submit.prevent="signup">
      <img src="../assets/logo.png" alt="../assets/logo.png" width="50%">
      <div class="field">
        <label for="firstName">First name</label>
        <input id="firstName" type="text" v-model="firstName">
      </div>
      <div class="field">
        <label for="lasttName">Last name</label>
        <input id="lastName" type="text" v-model="lastName">
      </div>
      <div style="margin-top: 25%;">
        <input style="border: 1px solid grey; border-radius: 10px; padding-left: 15px; margin: 10px 0;" class="accountInput" id="email" type="email" v-model="email" placeholder="Email">
      </div>
      <div>
        <input style="border: 1px solid grey; border-radius: 10px; padding-left: 15px; margin: 10px 0;" class="accountInput" id="password" type="password" v-model="password" placeholder="Password">
      </div>
      <div class="field">
        <label for="name">User name</label>
        <input id="name" type="text" v-model="alias">
      </div> -
      <p v-if="feedback != null" class="red-text center">{{ feedback }}</p>
      <div class="field center" style="margin-top: 5%;">
        <button class="button3">Sign up</button>
        <p class="textButton" style="text-align: center; margin-top: 10%;">Terms and conditions</p>
        </div>
        </form>
    </div>
</template>

<script>
import db from '@/firebase/init'
import firebase from 'firebase'

export default {
  name: "Signup",
  data() {
    return {
      firstName: null,
      lastName: null,
      email: null,
      password: null,
      alias: null,
      slug: null,
      feedback: null,
      credits: 0
      }
  },
  methods: {
    home() {
      this.$router.push({ name: "Home" });
    },
    signup(){
      if((this.email != null) && (this.password !== null)) {
        this.feedback = null
        firebase.auth().createUserWithEmailAndPassword(this.email, this.password)
        .then(cred => {
            db.collection('users').doc(cred.user.uid).set({
                first_name: this.firstName,
                last_name: this.lastName,
                email: this.email,
                alias: this.alias,
                geolocation: null,
                credits: this.credits,
                user_id: cred.user.uid
            })
        }).then(() => {
            this.$router.push({ name: 'HomeScreen' })
        })
        .catch(err => {
            this.feedback = err.message
        })
      } else {
        this.feedback = 'Please fill in all fields'
      }
    }
  }
};
</script>

<style <style scoped>
.signup{
  margin: auto;
  max-width: 400px;
  margin-top: 60px;
}
.signup .field{
  text-align: left;
  margin-bottom: 6px;
}
.signup button {
  width: 100%;
}
</style>