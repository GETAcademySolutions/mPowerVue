<template>
    <div class="ChargeStore">
      <h3>Purchase Charges</h3>
      <div id="feedbackDiv"></div>
    <div>
        <button class="button1" @click="purchase">Buy charge</button>
        <button class="button1" @click="home">Back</button>
        </div>
    </div>
</template>

<script>
export default {
  name: "BuyCharge",
  data() {
    return {};
  },
  methods: {
    home() {
      this.$router.push({ name: "Home" });
    },
    purchase() {
      this.$router.push({ name: "BuyChargeTime" });
    }
  }
};
</script>